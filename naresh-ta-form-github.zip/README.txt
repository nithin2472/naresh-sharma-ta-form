
Naresh Sharma — TA Claim Form
----------------------------
Files:
  - index.html
  - favicon.png

GitHub Pages Deployment:
1. Create a new GitHub repository (e.g., 'naresh-ta-form').
2. Upload index.html and favicon.png to the repository root.
3. Go to Settings -> Pages -> Build and Deployment -> Source -> main branch / root
4. Save. GitHub will provide a permanent URL like:
   https://yourusername.github.io/naresh-ta-form
5. Open URL to use the form. Static fields are auto-filled using localStorage.

Updating the form:
- Push updated index.html or favicon.png to the repo.
- GitHub Pages auto-updates the live site.
